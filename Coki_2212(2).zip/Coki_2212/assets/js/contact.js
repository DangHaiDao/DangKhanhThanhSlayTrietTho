//Validate form

$(document).ready(function(){
$("#btn-send-contact").click(function(){
   alert();

})
})